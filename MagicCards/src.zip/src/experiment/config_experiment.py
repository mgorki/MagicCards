behaviour = open("./data_recorded/behaviouralData/magic_cards_behaviour.txt", "a")  # defining the file to which behavioral data is saved
edfDataFolder = './data_recorded/edfData'
block_max = 2  # Number of blocks to be performed (if not aborted) ADJUST IT IN THE FINAL EXPERIMENT!!!
trial_max = 10  # Number of blocks to be performed per block

